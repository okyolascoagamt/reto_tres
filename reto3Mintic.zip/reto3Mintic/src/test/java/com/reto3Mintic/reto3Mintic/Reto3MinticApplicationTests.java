package com.reto3Mintic.reto3Mintic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3MinticApplicationTests {

	@Test
	void contextLoads() {
	}

}

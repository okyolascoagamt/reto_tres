
function listarAdmin(){
alert("Holaaaaaaaaaaa");
$.ajax({
url:"http://localhost:8080/ListarAdmin",
type: "GET",
datatype: "JSON",
success:function(respuesta){

}
});
}
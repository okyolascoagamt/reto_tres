package com.reto3Mintic.reto3Mintic.Entidades;


import java.io.Serializable;

public class ReportClient implements Serializable {
    public int total;
    public Client client;
}

package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Reservation;
import org.springframework.data.repository.CrudRepository;

public interface reservationCrudRepositorio extends CrudRepository<Reservation, Integer> {
}

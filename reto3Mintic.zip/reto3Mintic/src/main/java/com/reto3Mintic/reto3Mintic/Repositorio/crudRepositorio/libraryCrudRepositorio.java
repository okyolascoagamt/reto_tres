package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Library;
import org.springframework.data.repository.CrudRepository;

public interface libraryCrudRepositorio extends CrudRepository<Library, Integer> {
}

package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Score;
import org.springframework.data.repository.CrudRepository;

public interface scoreCrudRepositorio extends CrudRepository<Score, Integer> {
}

package com.reto3Mintic.reto3Mintic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto3MinticApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reto3MinticApplication.class, args);
	}

}

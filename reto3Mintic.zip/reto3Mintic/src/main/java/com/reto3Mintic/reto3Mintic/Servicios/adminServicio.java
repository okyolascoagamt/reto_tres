package com.reto3Mintic.reto3Mintic.Servicios;

import com.reto3Mintic.reto3Mintic.Entidades.Admin;
import com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio.adminCrudRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class adminServicio {

    private adminCrudRepositorio repositorio;

    public adminServicio(adminCrudRepositorio repositorio) {
        this.repositorio = repositorio;
    }

    public List<Admin> listaAdmin(){
        return (List<Admin>) repositorio.findAll();
    }

    public Optional<Admin> buscarAdmin(int id){
        return repositorio.findById(id); //Método para buscar administradores por Id
    }

    public String agregarAdmin(Admin admin){  //método para insertar
        if(buscarAdmin(admin.getIdAdmin()).isPresent()){
            return "Admin Ya existe";
        }else{
            repositorio.save(admin);
            return ("Admin guardado");
            }

    }


    public String actualizarAdmin(Admin admin){
        if(buscarAdmin(admin.getIdAdmin()).isPresent()){
            repositorio.save(admin);
            return "Admin modificado exitosamente";
        }else {
            return "El Admin a actualizar no se encontró";
        }
    }
    public void eliminarAdminAll(Admin admin){ //método para eliminar
        repositorio.delete(admin);
    }


    public String eliminarAdmin(Integer idAmin){
        if(buscarAdmin(idAmin).isPresent()){
            repositorio.deleteById(idAmin);
            return "Admin eliminado";
        }else {
            return "No se encuentra el Admin";
        }
    }

}

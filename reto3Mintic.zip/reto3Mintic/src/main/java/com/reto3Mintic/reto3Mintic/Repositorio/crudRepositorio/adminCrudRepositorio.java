package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Admin;
import org.springframework.data.repository.CrudRepository;

public interface adminCrudRepositorio extends CrudRepository<Admin, Integer> {
}

package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Message;
import org.springframework.data.repository.CrudRepository;

public interface messageCrudRepositorio extends CrudRepository<Message, Integer> {
}

package com.reto3Mintic.reto3Mintic.Repositorio.crudRepositorio;

import com.reto3Mintic.reto3Mintic.Entidades.Client;
import org.springframework.data.repository.CrudRepository;

public interface clientCrudRepositorio extends CrudRepository<Client, Integer> {
}
